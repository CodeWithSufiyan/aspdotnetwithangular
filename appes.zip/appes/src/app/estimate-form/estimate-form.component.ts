import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estimate-form',
  templateUrl: './estimate-form.component.html',
  styleUrls: ['./estimate-form.component.css']
})
export class EstimateFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
