import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EstimateFormComponent }   from '../app/estimate-form/estimate-form.component';

const routes: Routes = [
  // { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'estimate-form', component: EstimateFormComponent },
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}