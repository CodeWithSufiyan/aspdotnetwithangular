import { Injectable } from '@angular/core';
import { HttpModule, Headers } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { Entity } from './Entity';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST,GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  })
};
@Injectable({
  providedIn: 'root'
})
export class EntityService {

  constructor(private http: HttpClient) { }

  sBaseUrl = 'http://localhost:49676/Entity';

  getEntities(en: Entity): Observable<Entity[]> {
    return this.http.post<Entity[]>(this.sBaseUrl + '/GetEntities', en, httpOptions);
  }

  addEntity(en: Entity): Observable<Entity> {
    return this.http.post<Entity>(this.sBaseUrl + '/AddEntity', en, httpOptions);
  }

  updateEntity(en: Entity): Observable<Entity> {
    return this.http.post<Entity>(this.sBaseUrl + '/UpdateEntity', en, httpOptions);
  }

  deleteEntity(en: Entity): Observable<Entity> {
    return this.http.post<Entity>(this.sBaseUrl + '/DeleteEntity', en, httpOptions);
  }
}
