import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MovieListComponent } from './movie-list/movie-list.component';
import { ActorFormComponent } from './actor-form/actor-form.component';
import { ProducerFormComponent } from './producer-form/producer-form.component';
import { ProducerListComponent } from './producer-list/producer-list.component';
import { ActorListComponent } from './actor-list/actor-list.component';
import { MovieFormComponent } from './movie-form/movie-form.component';

const routes: Routes = [
  { path: '', redirectTo: '/movie-list', pathMatch: 'full' },
  { path: 'movie-list', component: MovieListComponent },
  { path: 'movie-form', component: MovieFormComponent },
  { path: 'producer-form', component: ProducerFormComponent },
  { path: 'producer-list', component: ProducerListComponent },
  { path: 'actor-form', component: ActorFormComponent },
  { path: 'actor-list', component: ActorListComponent },
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
