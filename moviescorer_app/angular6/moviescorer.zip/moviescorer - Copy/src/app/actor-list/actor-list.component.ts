import { Component, OnInit } from '@angular/core';
import { Entity } from '../Entity';
import { EntityService } from '../entity.service';

@Component({
  selector: 'app-actor-list',
  templateUrl: './actor-list.component.html',
  styleUrls: ['./actor-list.component.css']
})
export class ActorListComponent implements OnInit {
  arrActors: Entity[];
  actor: Entity = {
    n: 0,
    sFName: '',
    sMName: '',
    sLName: '',
    jSex: 0,
    dtDOB: '',
    sBio: '',
    jEntityType: 1
  };
  actorForEdit: Entity;
  constructor(private entityService: EntityService) { }

  ngOnInit() {
    // 1: producer
    // 2: actor
    this.actor.jEntityType = 2; // TODO: remove hardcoded 1
    this.fnGetEntities(this.actor);
  }

  fnGetEntities(en: Entity): void {
    this.entityService.getEntities(en).subscribe(arrEntities => this.arrActors = arrEntities);
  }

  fnViewEntity(actor: Entity): void {
    this.actorForEdit = actor;
  }

  fnUpdateEntity(): void {
    const oActor = this.actorForEdit;

    if (oActor.sFName === '' || oActor.sMName === '') {
      window.alert('First name & last name are required');
      return;
    }
    if (oActor.dtDOB === '') {
      window.alert('Enter date of birth');
      return;
    }
    console.log(this.actorForEdit);
    this.entityService.updateEntity(this.actorForEdit).subscribe(updatedEntity => console.log(updatedEntity));
  }

  fnDeleteEntity(prod: Entity): void {
    this.entityService.deleteEntity(prod).subscribe(deletedEntity => console.log(deletedEntity));
  }

  fnResetForm(): void {
    this.actorForEdit.sFName = '';
    this.actorForEdit.sMName = '';
    this.actorForEdit.sLName = '';
    this.actorForEdit.jSex = 1;
    this.actorForEdit.sBio = '';
  }
}
