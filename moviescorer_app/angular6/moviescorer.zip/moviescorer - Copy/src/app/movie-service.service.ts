import { Injectable } from '@angular/core';
import { HttpModule, Headers } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { Entity } from './Entity';
import { Movie } from './Movie';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST,GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  })
};
@Injectable({
  providedIn: 'root'
})
export class MovieServiceService {

  constructor(private http: HttpClient) { }

  sBaseUrl = 'http://localhost:49676/Movie';

  getMovies(movie: Movie): Observable<Movie[]> {
    return this.http.post<Movie[]>(this.sBaseUrl + '/GetMovies', movie, httpOptions);
  }

  addEntity(movie: Movie): Observable<Movie> {
    return this.http.post<Movie>(this.sBaseUrl + '/AddMovie', movie, httpOptions);
  }

  updateEntity(movie: Movie): Observable<Movie> {
    return this.http.post<Movie>(this.sBaseUrl + '/UpdateMovie', movie, httpOptions);
  }

  deleteEntity(movie: Movie): Observable<Movie> {
    return this.http.post<Movie>(this.sBaseUrl + '/DeleteMovie', movie, httpOptions);
  }
}
