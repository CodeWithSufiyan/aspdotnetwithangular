import { Component, OnInit } from '@angular/core';
import { Entity } from '../Entity';
import { EntityService } from '../entity.service';

@Component({
  selector: 'app-producer-form',
  templateUrl: './producer-form.component.html',
  styleUrls: ['./producer-form.component.css']
})
export class ProducerFormComponent implements OnInit {
  producer: Entity = {
    n: 0,
    sFName: '',
    sMName: '',
    sLName: '',
    jSex: 1,
    dtDOB: '',
    sBio: '',
    jEntityType: 1
  };
  constructor(private entityService: EntityService) { }

  ngOnInit() {
  }

  fnAddEntity(): void {
    const oProducer = this.producer;

    if (oProducer.sFName === '' || oProducer.sMName === '') {
      window.alert('First name & last name are required');
      return;
    }
    if (oProducer.dtDOB === '') {
      window.alert('Enter date of birth');
      return;
    }
    console.log(this.producer);
    this.entityService.updateEntity(this.producer).subscribe(updatedEntity => console.log(updatedEntity));
  }

  fnDeleteEntity(prod: Entity): void {
    this.entityService.deleteEntity(prod).subscribe(deletedEntity => console.log(deletedEntity));
  }

  fnResetForm(): void {
    this.producer.sFName = '';
    this.producer.sMName = '';
    this.producer.sLName = '';
    this.producer.jSex = 1;
    this.producer.sBio = '';
  }

}
