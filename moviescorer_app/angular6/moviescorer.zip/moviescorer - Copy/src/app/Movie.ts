import { Entity } from './Entity';

export class Movie {
    constructor(
        public n: number,
        public sMovieName: string,
        public oProducer: Entity,
        public jYrRelease: number,
        public sPlot: string,
        public sImgPoster: string,
        public arrActors: Entity[]
    ) {}
}
