
export class Entity {
    constructor(
        public n: number,
        public sFName: string,
        public sMName: string,
        public sLName: string,
        public jSex: number,
        public dtDOB: string,
        public sBio: string,
        public jEntityType: number,
    ) { }
}
