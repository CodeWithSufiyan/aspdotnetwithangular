import { Component, OnInit } from '@angular/core';
import { Entity } from '../Entity';
import { EntityService } from '../entity.service';

@Component({
  selector: 'app-actor-form',
  templateUrl: './actor-form.component.html',
  styleUrls: ['./actor-form.component.css']
})
export class ActorFormComponent implements OnInit {
  actor: Entity = {
    n: 0,
    sFName: '',
    sMName: '',
    sLName: '',
    jSex: 1,
    dtDOB: '',
    sBio: '',
    jEntityType: 1
  };
  constructor(private entityService: EntityService) { }

  ngOnInit() {
  }
  fnAddEntity(): void {
    const oActor = this.actor;

    if (oActor.sFName === '' || oActor.sMName === '') {
      window.alert('First name & last name are required');
      return;
    }
    if (oActor.dtDOB === '') {
      window.alert('Enter date of birth');
      return;
    }
    console.log(this.actor);
    this.entityService.updateEntity(this.actor).subscribe(updatedEntity => console.log(updatedEntity));
  }

  fnDeleteEntity(prod: Entity): void {
    this.entityService.deleteEntity(prod).subscribe(deletedEntity => console.log(deletedEntity));
  }

  fnResetForm(): void {
    this.actor.sFName = '';
    this.actor.sMName = '';
    this.actor.sLName = '';
    this.actor.jSex = 1;
    this.actor.sBio = '';
  }
}
