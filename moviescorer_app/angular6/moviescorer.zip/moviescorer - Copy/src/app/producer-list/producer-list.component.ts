import { Component, OnInit } from '@angular/core';
import { Entity } from '../Entity';
import { EntityService } from '../entity.service';

@Component({
  selector: 'app-producer-list',
  templateUrl: './producer-list.component.html',
  styleUrls: ['./producer-list.component.css']
})
export class ProducerListComponent implements OnInit {
  arrProducers: Entity[];
  producer: Entity = {
    n: 0,
    sFName: '',
    sMName: '',
    sLName: '',
    jSex: 0,
    dtDOB: '',
    sBio: '',
    jEntityType: 1
  };
  producerForEdit: Entity;
  constructor(private entityService: EntityService) { }

  ngOnInit() {
    // 1: producer
    // 2: actor
    this.producer.jEntityType = 1; // TODO: remove hardcoded 1
    this.fnGetEntities(this.producer);
  }
  fnGetEntities(en: Entity): void {
    this.entityService.getEntities(en).subscribe(arrEntities => this.arrProducers = arrEntities);
  }

  fnViewEntity(prod: Entity): void {
    this.producerForEdit = prod;
  }

  fnUpdateEntity(): void {
    const oProducer = this.producerForEdit;

    if (oProducer.sFName === '' || oProducer.sMName === '') {
      window.alert('First name & last name are required');
      return;
    }
    if (oProducer.dtDOB === '') {
      window.alert('Enter date of birth');
      return;
    }
    console.log(this.producerForEdit);
    this.entityService.updateEntity(this.producerForEdit).subscribe(updatedEntity => console.log(updatedEntity));
  }

  fnDeleteEntity(prod: Entity): void {
    this.entityService.deleteEntity(prod).subscribe(deletedEntity => console.log(deletedEntity));
  }

  fnResetForm(): void {
    this.producerForEdit.sFName = '';
    this.producerForEdit.sMName = '';
    this.producerForEdit.sLName = '';
    this.producerForEdit.jSex = 1;
    this.producerForEdit.sBio = '';
  }
}
