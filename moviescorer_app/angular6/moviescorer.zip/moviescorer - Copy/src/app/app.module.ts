import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './/app-routing.module';
import { MovieListComponent } from './movie-list/movie-list.component';
import { ProducerFormComponent } from './producer-form/producer-form.component';
import { ActorFormComponent } from './actor-form/actor-form.component';
import { ProducerListComponent } from './producer-list/producer-list.component';
import { ActorListComponent } from './actor-list/actor-list.component';
import { MovieFormComponent } from './movie-form/movie-form.component';
import { MessagesComponent } from './messages/messages.component';

@NgModule({
  declarations: [
    AppComponent,
    MovieListComponent,
    ProducerFormComponent,
    ActorFormComponent,
    ProducerListComponent,
    ActorListComponent,
    MovieFormComponent,
    MessagesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
