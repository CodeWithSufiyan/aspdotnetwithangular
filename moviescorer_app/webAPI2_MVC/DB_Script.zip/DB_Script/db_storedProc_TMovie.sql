﻿CREATE PROCEDURE spAddMovie(
    @sMovieName nvarchar(64),
	@nProducerEntityFK bigint,
	@jYrRelease int,
	@sPlot nvarchar(1028),
	@sImgPoster nvarchar(1028),
	@jStatusBit int,
	@dtStamp datetime
)
AS BEGIN
	insert into TMovie(sMovieName,nProducerEntityFK,jYrRelease,sPlot,sImgPoster,jStatusBit,dtStamp)
	values(@sMovieName,@nProducerEntityFK,@jYrRelease,@sPlot,@sImgPoster,@jStatusBit,@dtStamp)
END 

CREATE PROCEDURE spAddMovieEntityMapping(
	@nMovieFK bigint,
	@nActorEntityFK bigint,
	@jStatusBit int,
	@dtStamp datetime
)
AS BEGIN
	insert into TMovieEntityMap(nMovieFK,nActorEntityFK,jStatusBit,dtStamp)
	values(@nMovieFK,@nActorEntityFK,@jStatusBit,@dtStamp)
END 
CREATE PROCEDURE spGetMovieEntityMappings(
	@nMovieFK bigint
)
AS BEGIN
	select * from TMovieEntityMap where nMovieFK=@nMovieFK AND jStatusBit=1
END

CREATE PROCEDURE spUpdateMovie(
	@n bigint,
    @sMovieName nvarchar(64),
	@nProducerEntityFK bigint,
	@jYrRelease int,
	@sPlot nvarchar(1028),
	@sImgPoster nvarchar(1028),
	@jStatusBit int,
	@dtStamp datetime
)
AS BEGIN
	update TMovie 
	set sMovieName=@sMovieName,nProducerEntityFK=@nProducerEntityFK,jYrRelease=@jYrRelease,sPlot=@sPlot,sImgPoster=@sImgPoster,jStatusBit=@jStatusBit,dtStamp=@dtStamp where n=@n
END 

CREATE PROCEDURE spGetMovies
AS BEGIN
	select * from TMovie where jStatusBit=1
END

CREATE PROCEDURE spDeleteMovie(
	@n bigint,
	@jStatusBit int,
	@dtStamp datetime
)
AS BEGIN
	update TEntity
	set jStatusBit=@jStatusBit,dtStamp=@dtStamp where n=@n
END 
