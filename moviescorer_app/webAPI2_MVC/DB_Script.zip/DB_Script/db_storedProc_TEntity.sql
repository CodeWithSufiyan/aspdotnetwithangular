﻿CREATE PROCEDURE spAddEntity(
	@sFName nvarchar(64),
	@sMName nvarchar(64),
	@sLName nvarchar(64),
	@jSex int,
	@dtDOB datetime,
	@sBio nvarchar(512),
	@jEntityType int,
	@jStatusBit int,
	@dtStamp datetime
)
AS BEGIN
	insert into TEntity(sFName,sMName,sLName,jSex,dtDOB,sBio,jEntityType,jStatusBit,dtStamp)
	values(@sFName,@sMName,@sLName,@jSex,@dtDOB,@sBio,@jEntityType,@jStatusBit,@dtStamp)
END 

CREATE PROCEDURE spUpdateEntity(
	@n bigint,
	@sFName nvarchar(64),
	@sMName nvarchar(64),
	@sLName nvarchar(64),
	@jSex int,
	@dtDOB datetime,
	@sBio nvarchar(512),
	@jEntityType int,
	@jStatusBit int,
	@dtStamp datetime
)
AS BEGIN
	update TEntity
	set sFName=@sFName,sMName=@sMName,sLName=@sLName,jSex=@jSex,dtDOB=@dtDOB,sBio=@sBio,jEntityType=@jEntityType,jStatusBit=@jStatusBit,dtStamp=@dtStamp where n=@n
END 

CREATE PROCEDURE spGetProducerEntities
AS BEGIN
	select * from TEntity where jStatusBit=1 AND jEntityType=1
END
CREATE PROCEDURE spGetActorEntity(
	@n bigint
)
AS BEGIN
	select * from TEntity where n=@n
END
CREATE PROCEDURE spGetActorEntities
AS BEGIN
	select * from TEntity where jStatusBit=1 AND jEntityType=2
END

CREATE PROCEDURE spDeleteEntity(
	@jEntityType bigint,
	@jStatusBit int,
	@dtStamp datetime
)
AS BEGIN
	update TEntity
	set jStatusBit=@jStatusBit,dtStamp=@dtStamp where n=@n
END 
